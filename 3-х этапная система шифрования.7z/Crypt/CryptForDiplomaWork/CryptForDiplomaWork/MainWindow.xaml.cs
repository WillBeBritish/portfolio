﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CryptForDiplomaWork
{
    public partial class MainWindow : Window
    {
        string passSecond = ""; //Для второго шифрования
        char ACIIYet; //ACII готовая перекодированная 
        int Z = 127; //Алфавит
        int ACIIPass; //ACII код
        string CryptedPass = ""; //Готовый шифрованный пароль
        string passThird = "";
        int len;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void CheckBtn_Click(object sender, RoutedEventArgs e)
        {

            MessageBox.Show(CryptPass());

        }

        public string CryptPass1(PasswordBox Boxik)
        {
            len = Boxik.Password.Length; //Длина пароля 

            for (int i = 0; i < len; i++)
            {
                ACIIPass = (int)Boxik.Password[i]; //Перевод в ACII

                //Первое шифрование 

                ACIIPass = ACIIPass * 2;

                if (ACIIPass > Z) // Проверка, ACII больше ли он допустимого значения алфавита
                {
                    ACIIPass = ACIIPass - Z; //начать сначала в случае true
                }
                ACIIYet = Convert.ToChar(ACIIPass);
                CryptedPass = CryptedPass + Convert.ToString(ACIIYet);

                //Конец Первого шифрования

            }

            return CryptedPass;

        }

        public string CryptPass2(string pass)
        {
            //Начало второго шифрования

            int len2 = len / 2; //пол длины нужно для удаления половины шифра, невозможно расшифровать

            for (int j = 0; j <= len2; j++)
            {
                passSecond = CryptedPass.Remove(0, j); //Удаление половины пароля 
            }

            return passSecond;
            //Конец второго шифрования

        }

        public string CryptPass3(string pass)
        {
            //Начало третьего шифрования 

            CryptedPass = "";
            ACIIPass = 0;
            int len3 = passSecond.Length;
            for (int mm = 0; mm < len3; mm++)
            {
                ACIIPass = (int)passSecond[mm]; //Перевод в ACII

                ACIIPass = ACIIPass + 5;

                if (ACIIPass > Z) // Проверка, ACII больше ли он допустимого значения алфавита
                {
                    ACIIPass = ACIIPass - Z; //начать сначала в случае true
                }
                ACIIYet = Convert.ToChar(ACIIPass);
                CryptedPass = CryptedPass + Convert.ToString(ACIIYet);
                passThird = CryptedPass;
            }

            //Конец третьего шифрования


            return passThird;
        }

        public string CryptPass()
        {
           return  CryptPass3(CryptPass2(CryptPass1(PassBox)));

        }
    }
}
